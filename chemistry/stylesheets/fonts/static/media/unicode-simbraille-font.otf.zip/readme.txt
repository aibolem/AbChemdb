﻿The font file in this archive was created using Fontstruct the free, online
font-building tool.
This font was created by “bellaanderson”*.
This font has a homepage where this archive and other versions may be found:
https://fontstruct.com/fontstructions/show/1534535

*NOTE: “Unicode Simbraille Font” was originally cloned (copied) from the
FontStruction “Unicode Braille Font”
(https://fontstruct.com/fontstructions/show/1534383) by “bellaanderson”,
which is licensed under a Creative Commons CC0 Public Domain Dedication license
(http://creativecommons.org/publicdomain/zero/1.0/).

Try Fontstruct at https://fontstruct.com
It’s easy and it’s fun.

Fontstruct is copyright ©2018-2026 Rob Meek

LEGAL NOTICE:
In using this font you must comply with the licensing terms described in the
file “license.txt” included with this archive.
If you redistribute the font file in this archive, it must be accompanied by all
the other files from this archive, including this one.
